"""Lattice package."""

__all__ = ["__version__"]

__version__ = "0.4.0"
